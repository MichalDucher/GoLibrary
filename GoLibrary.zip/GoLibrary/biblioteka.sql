-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 07 Lut 2022, 00:01
-- Wersja serwera: 10.4.21-MariaDB
-- Wersja PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `biblioteka`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `books`
--

CREATE TABLE `books` (
  `id_book` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `author_name` varchar(50) NOT NULL,
  `author_lastname` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `statebook` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `books`
--

INSERT INTO `books` (`id_book`, `title`, `author_name`, `author_lastname`, `section`, `statebook`) VALUES
(1, '1894', 'George', 'Orwell', 'Matematyka', 0),
(3, 'Podstawy teorii obwodów Tom I', 'Jerzy', 'Osiowski', 'Elektronika', 0),
(4, 'Podstawy teorii obwodów Tom I', 'Jerzy', 'Osiowski', 'Elektronika', 1),
(5, 'Podstawy teorii obwodów Tom I', 'Jerzy', 'Osiowski', 'Elektronika', 1),
(6, 'Podstawy teorii obwodów Tom I', 'Jerzy', 'Osiowski', 'Elektronika', 1),
(7, 'Podstawy teorii obwodów Tom I', 'Jerzy', 'Osiowski', 'Elektronika', 1),
(8, 'Niemiecki w cztery tygodnie. Kurs podstawowy z nag', 'Przemysław', 'Wolski', 'Języki obce', 0),
(9, 'Niemiecki w cztery tygodnie. Kurs podstawowy z nag', 'Przemysław', 'Wolski', 'Języki obce', 1),
(10, 'Niemiecki w cztery tygodnie. Kurs podstawowy z nag', 'Przemysław', 'Wolski', 'Języki obce', 1),
(11, 'Niemiecki w cztery tygodnie. Kurs podstawowy z nag', 'Przemysław', 'Wolski', 'Języki obce', 1),
(12, 'Niemiecki w cztery tygodnie. Kurs podstawowy z nag', 'Przemysław', 'Wolski', 'Języki obce', 1),
(13, 'Niemiecki w cztery tygodnie. Kurs podstawowy z nag', 'Przemysław', 'Wolski', 'Języki obce', 1),
(14, 'Niemiecki w cztery tygodnie. Kurs podstawowy z nag', 'Przemysław', 'Wolski', 'Języki obce', 1),
(15, 'Niemiecki w cztery tygodnie. Kurs podstawowy z nag', 'Przemysław', 'Wolski', 'Języki obce', 1),
(16, 'Niemiecki w cztery tygodnie. Kurs podstawowy z nag', 'Przemysław', 'Wolski', 'Języki obce', 1),
(17, 'Niemiecki w cztery tygodnie. Kurs podstawowy z nag', 'Przemysław', 'Wolski', 'Języki obce', 1),
(18, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(19, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(20, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(21, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(22, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(23, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(24, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(25, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(26, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(27, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(28, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(29, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(30, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(31, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(32, 'Harry Potter ', 'J.K.', 'Rowlling', 'Matematyka', 1),
(33, 'Metrologia Elektryczna', 'Augustyn', 'Chwaleba', 'Metrologia', 1),
(34, 'Metrologia Elektryczna', 'Augustyn', 'Chwaleba', 'Metrologia', 1),
(35, 'Metrologia Elektryczna', 'Augustyn', 'Chwaleba', 'Metrologia', 1),
(36, 'Metrologia Elektryczna', 'Augustyn', 'Chwaleba', 'Metrologia', 1),
(37, 'Metrologia Elektryczna', 'Augustyn', 'Chwaleba', 'Metrologia', 1),
(38, 'Metrologia Elektryczna', 'Augustyn', 'Chwaleba', 'Metrologia', 1),
(39, 'Metrologia Elektryczna', 'Augustyn', 'Chwaleba', 'Metrologia', 1),
(40, 'Metrologia Elektryczna', 'Augustyn', 'Chwaleba', 'Metrologia', 1),
(41, 'Metrologia Elektryczna', 'Augustyn', 'Chwaleba', 'Metrologia', 1),
(42, 'Metrologia Elektryczna', 'Augustyn', 'Chwaleba', 'Metrologia', 1),
(43, 'Metrologia Elektryczna', 'Augustyn', 'Chwaleba', 'Metrologia', 1),
(44, 'Metrologia Elektryczna', 'Augustyn', 'Chwaleba', 'Metrologia', 1),
(45, 'Pneumatyczne pomiary długości', 'Andrzej', 'Zelczak', 'Metrologia', 1),
(46, 'Pneumatyczne pomiary długości', 'Andrzej', 'Zelczak', 'Metrologia', 1),
(47, 'Pneumatyczne pomiary długości', 'Andrzej', 'Zelczak', 'Metrologia', 1),
(48, 'Pneumatyczne pomiary długości', 'Andrzej', 'Zelczak', 'Metrologia', 1),
(49, 'Pomiary Gwintów w budowie maszyn', 'Jan', 'Malinowski', 'Metrologia', 1),
(50, 'Pomiary Gwintów w budowie maszyn', 'Jan', 'Malinowski', 'Metrologia', 1),
(51, 'Pomiary Gwintów w budowie maszyn', 'Jan', 'Malinowski', 'Metrologia', 1),
(52, 'Pomiary Gwintów w budowie maszyn', 'Jan', 'Malinowski', 'Metrologia', 1),
(66, 'Analiza Matematyczna', 'Włodzimierz', 'Krysicki', 'Matematyka', 1),
(67, 'Analiza Matematyczna', 'Włodzimierz', 'Krysicki', 'Matematyka', 1),
(68, 'Analiza Matematyczna', 'Włodzimierz', 'Krysicki', 'Matematyka', 1),
(69, 'Analiza Matematyczna', 'Włodzimierz', 'Krysicki', 'Matematyka', 1),
(70, 'Analiza Matematyczna', 'Włodzimierz', 'Krysicki', 'Matematyka', 1),
(71, 'Analiza Matematyczna', 'Włodzimierz', 'Krysicki', 'Matematyka', 1),
(72, 'Analiza Matematyczna', 'Włodzimierz', 'Krysicki', 'Matematyka', 1),
(73, 'Analiza Matematyczna', 'Włodzimierz', 'Krysicki', 'Matematyka', 1),
(74, 'Analiza Matematyczna', 'Włodzimierz', 'Krysicki', 'Matematyka', 1),
(75, 'Analiza Matematyczna', 'Włodzimierz', 'Krysicki', 'Matematyka', 1),
(76, 'Analiza Matematyczna', 'Włodzimierz', 'Krysicki', 'Matematyka', 1),
(77, 'Analiza Matematyczna', 'Włodzimierz', 'Krysicki', 'Matematyka', 1),
(78, 'Analiza Matematyczna', 'Włodzimierz', 'Krysicki', 'Matematyka', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `leding`
--

CREATE TABLE `leding` (
  `id_leding` int(11) NOT NULL,
  `login` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `id_book` int(11) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `state` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `leding`
--

INSERT INTO `leding` (`id_leding`, `login`, `name`, `lastName`, `title`, `id_book`, `date`, `state`) VALUES
(228, 'młot', 'Jan', 'Nowak', 'Niemiecki w cztery tygodnie. Kurs podstawowy z nag', 8, '2021-12-27', 'oczekujący'),
(229, 'żalno', 'Adam', 'Kowalski', 'Podstawy teorii obwodów Tom I', 3, '2021-12-27', 'oczekujący'),
(234, 'miotacz', 'Michał', 'Ducher', '1894', 1, '2022-01-28', 'wydano');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `users`
--

INSERT INTO `users` (`id`, `name`, `lastname`, `login`, `password`) VALUES
(1, 'Michał', 'Ducher', 'miotacz', '123'),
(2, 'Michał', 'Ducher', 'test', '123'),
(3, 'Angelika', 'Nojmiler', 'angelika1', '12345'),
(4, 'Julian', 'Wolski', 'chudy', '1234'),
(5, 'Karol', 'Ducher', 'karol', '123'),
(6, 'Jan', 'Nowak', 'młot', '123'),
(7, 'Adam', 'Kowalski', 'żalno', '123'),
(10, 'siema', 'siema', 'siema', 'siema');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id_book`);

--
-- Indeksy dla tabeli `leding`
--
ALTER TABLE `leding`
  ADD PRIMARY KEY (`id_leding`),
  ADD UNIQUE KEY `id_book` (`id_book`);

--
-- Indeksy dla tabeli `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `books`
--
ALTER TABLE `books`
  MODIFY `id_book` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT dla tabeli `leding`
--
ALTER TABLE `leding`
  MODIFY `id_leding` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=235;

--
-- AUTO_INCREMENT dla tabeli `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
