Hi!

This is a simple library managment system



SQL file have to be setup on localhost (i prefer XAMPP),
or wherever you want but then u have to change connection string in file "Funkcje.cs". It look's like code below :)

public static MySqlConnection conn = new MySqlConnection("server=127.0.0.1;uid=root;pwd=;database=biblioteka");
							_____________________________________________________
							^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
I think that's all, have a nice day :)