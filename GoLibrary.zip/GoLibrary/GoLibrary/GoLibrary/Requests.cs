﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace GoLibrary
{
    public partial class Requests : UserControl
    {
        public static MySqlConnection conn = Funkcje.conn;
        public Requests()
        {
            InitializeComponent();
        }
        string idlab = "";
        private void reqDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.reqDataGrid.Rows[e.RowIndex];
                idlab = row.Cells[0].Value.ToString();
            }
        }

        private void Requests_Load(object sender, EventArgs e)
        {
            /*
            try
            {
                    
                string querry = $"SELECT * FROM leding WHERE state='oczekujący'";
                MySqlDataAdapter adap = new MySqlDataAdapter(querry, conn);
                conn.Open();
                DataSet ds = new DataSet();
                adap.Fill(ds);
                reqDataGrid.DataSource = ds.Tables[0];
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "błąd");
            }
            */
            
        }

        private void reqButton_Click(object sender, EventArgs e)
        {
            string idled = idlab;
            if (Funkcje.updateleding(idled))
                MessageBox.Show("Wypozyczono!");
            else
                MessageBox.Show("coś poszło nie tak :/");
            
        }

        private void searchButton1_Click(object sender, EventArgs e)
        {
            try
            {

                string querry = $"SELECT * FROM leding WHERE login='{searchBox1.Text}' AND state='oczekujący'";
                MySqlDataAdapter adap = new MySqlDataAdapter(querry, conn);
                conn.Open();
                DataSet ds = new DataSet();
                adap.Fill(ds);
                reqDataGrid.DataSource = ds.Tables[0];
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "błąd");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
