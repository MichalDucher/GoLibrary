﻿
namespace GoLibrary
{
    partial class AdminFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.logout = new System.Windows.Forms.Button();
            this.qButton = new System.Windows.Forms.Button();
            this.StudentsButton = new System.Windows.Forms.Button();
            this.BookButton = new System.Windows.Forms.Button();
            this.zwrotyfrm1 = new GoLibrary.zwrotyfrm();
            this.requests1 = new GoLibrary.Requests();
            this.addBookFrm1 = new GoLibrary.AddBookFrm();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::GoLibrary.Properties.Resources.tlo11;
            this.panel1.Controls.Add(this.logout);
            this.panel1.Controls.Add(this.qButton);
            this.panel1.Controls.Add(this.StudentsButton);
            this.panel1.Controls.Add(this.BookButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(192, 600);
            this.panel1.TabIndex = 1;
            // 
            // logout
            // 
            this.logout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.logout.FlatAppearance.BorderSize = 0;
            this.logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.logout.ForeColor = System.Drawing.Color.White;
            this.logout.Location = new System.Drawing.Point(0, 554);
            this.logout.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(200, 34);
            this.logout.TabIndex = 4;
            this.logout.Text = "Wyloguj";
            this.logout.UseVisualStyleBackColor = false;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // qButton
            // 
            this.qButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.qButton.FlatAppearance.BorderSize = 0;
            this.qButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.qButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.qButton.ForeColor = System.Drawing.Color.White;
            this.qButton.Location = new System.Drawing.Point(0, 208);
            this.qButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.qButton.Name = "qButton";
            this.qButton.Size = new System.Drawing.Size(200, 34);
            this.qButton.TabIndex = 3;
            this.qButton.Text = "Prosby";
            this.qButton.UseVisualStyleBackColor = false;
            this.qButton.Click += new System.EventHandler(this.wyp_Click);
            // 
            // StudentsButton
            // 
            this.StudentsButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.StudentsButton.FlatAppearance.BorderSize = 0;
            this.StudentsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StudentsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.StudentsButton.ForeColor = System.Drawing.Color.White;
            this.StudentsButton.Location = new System.Drawing.Point(0, 167);
            this.StudentsButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.StudentsButton.Name = "StudentsButton";
            this.StudentsButton.Size = new System.Drawing.Size(200, 34);
            this.StudentsButton.TabIndex = 2;
            this.StudentsButton.Text = "Wopożyczenia";
            this.StudentsButton.UseVisualStyleBackColor = false;
            this.StudentsButton.Click += new System.EventHandler(this.StudentsButton_Click);
            // 
            // BookButton
            // 
            this.BookButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.BookButton.FlatAppearance.BorderSize = 0;
            this.BookButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BookButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.BookButton.ForeColor = System.Drawing.Color.White;
            this.BookButton.Location = new System.Drawing.Point(0, 128);
            this.BookButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BookButton.Name = "BookButton";
            this.BookButton.Size = new System.Drawing.Size(200, 34);
            this.BookButton.TabIndex = 1;
            this.BookButton.Text = "Dodaj ksiazke";
            this.BookButton.UseVisualStyleBackColor = false;
            this.BookButton.Click += new System.EventHandler(this.AddBookButton_Click);
            // 
            // zwrotyfrm1
            // 
            this.zwrotyfrm1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.zwrotyfrm1.Location = new System.Drawing.Point(192, 0);
            this.zwrotyfrm1.Name = "zwrotyfrm1";
            this.zwrotyfrm1.Size = new System.Drawing.Size(808, 600);
            this.zwrotyfrm1.TabIndex = 4;
            // 
            // requests1
            // 
            this.requests1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.requests1.Location = new System.Drawing.Point(192, 0);
            this.requests1.Name = "requests1";
            this.requests1.Size = new System.Drawing.Size(808, 600);
            this.requests1.TabIndex = 3;
            // 
            // addBookFrm1
            // 
            this.addBookFrm1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addBookFrm1.Location = new System.Drawing.Point(192, 0);
            this.addBookFrm1.Margin = new System.Windows.Forms.Padding(5);
            this.addBookFrm1.Name = "addBookFrm1";
            this.addBookFrm1.Size = new System.Drawing.Size(808, 600);
            this.addBookFrm1.TabIndex = 2;
            // 
            // AdminFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 600);
            this.Controls.Add(this.zwrotyfrm1);
            this.Controls.Add(this.requests1);
            this.Controls.Add(this.addBookFrm1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AdminFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.Button qButton;
        private System.Windows.Forms.Button StudentsButton;
        private System.Windows.Forms.Button BookButton;
        private AddBookFrm addBookFrm1;
        private Requests requests1;
        private zwrotyfrm zwrotyfrm1;
    }
}