﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GoLibrary
{
    public partial class LogForm : Form
    {
        public LogForm()
        {
            InitializeComponent();
        }


        public static string logins;
        private void logButton_Click(object sender, EventArgs e)
        {
            if (loginBox.Text == "" || passBox.Text == "")
                MessageBox.Show("Wszystkie pola muszą zostać wypełnione");
            else if(loginBox.Text == "admin" && passBox.Text == "admin")
            {
                new AdminFrm().Show();
                this.Hide();
            }
            else if (Funkcje.login(loginBox.Text, passBox.Text))
            {
                logins = loginBox.Text;
                MessageBox.Show("Zalogowano!");
                new UserForm().Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Taki użytkownik nie istnieje!");
            }
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new RegForm().Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
