﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GoLibrary
{
    public partial class AddBookFrm : UserControl
    {
        public AddBookFrm()
        {
            InitializeComponent();
        }

        private void AddBookFrm_Load(object sender, EventArgs e)
        {

        }

        private void AddBookButton_Click(object sender, EventArgs e)
        {
            int q;
            bool czy = false;
            if (addtitleBox.Text == "" || addanameBox.Text == "" || addalnameBox.Text == "" || addsectBox.Text == "" || quanBox.Text == "")
                MessageBox.Show("Wszystkie pola muszą zostać wypełnione!");
            if (int.TryParse(quanBox.Text, out q))
            {
                for (int i = q; i > 0; i--)
                {
                    if (Funkcje.addbook(addtitleBox.Text, addanameBox.Text, addalnameBox.Text, addsectBox.Text))
                        czy = true;
                    else
                    {
                        czy = false;
                        break;
                    }
                }
            }
            else
                MessageBox.Show("Zła ilość!");
            if (czy)
                MessageBox.Show("Dodano " + quanBox.Text + " książek!");
            else
                MessageBox.Show("Coś poszło nie tak :/");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
