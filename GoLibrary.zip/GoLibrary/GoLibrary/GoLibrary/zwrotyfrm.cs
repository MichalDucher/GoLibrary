﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace GoLibrary
{
    public partial class zwrotyfrm : UserControl
    {
        public zwrotyfrm()
        {
            InitializeComponent();
        }
        string idbook = "";
        string idled = "";
        public static MySqlConnection conn = Funkcje.conn;
        private void zwrotyfrm_Load(object sender, EventArgs e)
        {
            /*
            try
            {

                string querry = $"SELECT * FROM leding WHERE state='wydano'";
                MySqlDataAdapter adap = new MySqlDataAdapter(querry, conn);
                conn.Open();
                DataSet ds = new DataSet();
                adap.Fill(ds);
                ledGrid.DataSource = ds.Tables[0];
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "błąd");
            }
            */
        }

        private void zwrotButton_Click(object sender, EventArgs e)
        {
            if (idbook == "" || idled == "")
                MessageBox.Show("Proszę zaznaczyć wiersz!");
            else if (Funkcje.deleteleding(idled, idbook))
                MessageBox.Show("Zwrócono!");
            else
                MessageBox.Show("Coś poszło nie tak :/");
        }

        private void ledGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.ledGrid.Rows[e.RowIndex];
                idled = row.Cells[0].Value.ToString();
                idbook = row.Cells[5].Value.ToString();
            }
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            try
            {

                string querry = $"SELECT * FROM leding WHERE state='wydano' AND login='{searchBox.Text}'";
                MySqlDataAdapter adap = new MySqlDataAdapter(querry, conn);
                conn.Open();
                DataSet ds = new DataSet();
                adap.Fill(ds);
                ledGrid.DataSource = ds.Tables[0];
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "błąd");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
