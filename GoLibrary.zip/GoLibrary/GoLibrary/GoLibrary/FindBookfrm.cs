﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace GoLibrary
{
    public partial class FindBookfrm : UserControl
    {
        public FindBookfrm()
        {
            InitializeComponent();
        }
       
        string id1 = "";
        string title1 = "";
        public static MySqlConnection conn = Funkcje.conn;
        private void button1_Click(object sender, EventArgs e)
        {
            if (Funkcje.findbook(titleBox.Text, anameBox.Text, alnameBox.Text))
                PobierzDane(titleBox.Text, anameBox.Text, alnameBox.Text);
            else
                MessageBox.Show("Brak wyników wyszukiwania");


        }
        private void showAll_Click(object sender, EventArgs e)
        {
            findall(secList.Text);
        }
        public void PobierzDane(string title, string name, string lname)
        {

            try
            {
                string querry;
                #region ściana płaczu 
                if (title != "" && name == "" && lname == "")
                {
                    querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE title LIKE '%{title}%' AND statebook='1' GROUP BY title";
                }
                else if (title == "" && name != "" && lname == "")
                {
                    querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE author_name LIKE '%{name}%' AND statebook='1' GROUP BY title";
                }
                else if (title == "" && name == "" && lname != "")
                {
                    querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE author_lastname LIKE '%{lname}%' AND statebook='1' GROUP BY title";
                }
                else if (title == "" && name != "" && lname != "")
                {
                    querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE author_name LIKE '%{name}%' AND author_lastname LIKE '%{lname}%' AND statebook='1' GROUP BY title";
                }
                else if (title != "" && name != "" && lname == "")
                {
                    querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE title LIKE '%{title}%' AND author_name LIKE '%{name}%' AND statebook='1' GROUP BY title";
                }
                else if (title != "" && name == "" && lname != "")
                {
                    querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE title LIKE '%{title}%' AND author_lastname LIKE '%{lname}%' AND statebook='1' GROUP BY title";
                }
                else
                {
                    querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE title LIKE '%{title}%' AND author_name LIKE '%{name}%'AND author_lastname LIKE '%{lname}%' AND statebook='1' GROUP BY title";
                }
                #endregion
                MySqlDataAdapter adap = new MySqlDataAdapter(querry, conn);
                conn.Open();
                DataSet ds = new DataSet();
                adap.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "błąd");
            }

        }
        public void findall(string sec)
        {
            string querry;
            try
            {
                if(sec == "")
                     querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE statebook='1' GROUP BY title";
                else  
                    querry = $"SELECT *, COUNT(title) AS ilosc FROM books WHERE section='{sec}' AND statebook='1'";
                MySqlDataAdapter adap = new MySqlDataAdapter(querry, conn);
                conn.Open();
                DataSet ds = new DataSet();
                adap.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
                conn.Close();
                dataGridView1.Columns["id_book"].Visible = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "błąd");
            }

        }
        public void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                id1 = row.Cells["id_book"].Value.ToString();
                title1 = row.Cells["title"].Value.ToString();
            }
            
        }
        private void borrowButton_Click_1(object sender, EventArgs e)
        {
            
            string name = Funkcje.myname(LogForm.logins);
            string lastname = Funkcje.mylastname(LogForm.logins);
            string title = title1.ToString();
            string id = id1.ToString();
            if (id1 == "" || title1 == "")
                MessageBox.Show("prosze wybrać książkę");
            else if (Funkcje.leding(name, lastname, title, id))
            {
                MessageBox.Show("Wysłano zapytanie!");
                id1 = "";
                title1 = "";
            }
            else
                MessageBox.Show("coś poszło nie tak :/");
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
