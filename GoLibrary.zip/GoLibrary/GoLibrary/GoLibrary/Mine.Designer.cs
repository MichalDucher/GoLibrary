﻿
namespace GoLibrary
{
    partial class Mine
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mine));
            this.wypoGrid = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.denButton = new System.Windows.Forms.Button();
            this.comboBoxled = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.wypoGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // wypoGrid
            // 
            this.wypoGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.wypoGrid.Location = new System.Drawing.Point(3, 229);
            this.wypoGrid.Name = "wypoGrid";
            this.wypoGrid.RowHeadersWidth = 51;
            this.wypoGrid.RowTemplate.Height = 24;
            this.wypoGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.wypoGrid.Size = new System.Drawing.Size(802, 368);
            this.wypoGrid.TabIndex = 0;
            this.wypoGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.wypoGrid_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Myanmar Text", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.label1.Location = new System.Drawing.Point(14, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "Moje wypozyczenia";
            // 
            // denButton
            // 
            this.denButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.denButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.denButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.denButton.ForeColor = System.Drawing.Color.White;
            this.denButton.Location = new System.Drawing.Point(589, 188);
            this.denButton.Name = "denButton";
            this.denButton.Size = new System.Drawing.Size(216, 35);
            this.denButton.TabIndex = 15;
            this.denButton.Text = "Anuluj prosbe";
            this.denButton.UseVisualStyleBackColor = false;
            this.denButton.Click += new System.EventHandler(this.denButton_Click);
            // 
            // comboBoxled
            // 
            this.comboBoxled.AutoCompleteCustomSource.AddRange(new string[] {
            "Wszystko",
            "Oczekujące ",
            "Wydane"});
            this.comboBoxled.FormattingEnabled = true;
            this.comboBoxled.Items.AddRange(new object[] {
            "Wszystko",
            "Oczekujące",
            "Wydane"});
            this.comboBoxled.Location = new System.Drawing.Point(20, 54);
            this.comboBoxled.Name = "comboBoxled";
            this.comboBoxled.Size = new System.Drawing.Size(121, 24);
            this.comboBoxled.TabIndex = 16;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(20, 84);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 33);
            this.button1.TabIndex = 17;
            this.button1.Text = "Szukaj";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(784, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(21, 20);
            this.button2.TabIndex = 19;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Mine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBoxled);
            this.Controls.Add(this.denButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.wypoGrid);
            this.Name = "Mine";
            this.Size = new System.Drawing.Size(808, 600);
            ((System.ComponentModel.ISupportInitialize)(this.wypoGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView wypoGrid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button denButton;
        private System.Windows.Forms.ComboBox comboBoxled;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}
