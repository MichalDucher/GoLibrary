﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GoLibrary
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
        }
        

        private void regButton_Click(object sender, EventArgs e)
        {
            if (nameBox.Text == "" || lnameBox.Text == "" || loginrBox.Text == "" || passrBox.Text == "" || passrcBox.Text == "")
                MessageBox.Show("wszystkie pola muszą zostać wypełnione!");
            else if (passrBox.Text != passrcBox.Text)
                MessageBox.Show("Podane hasła się różnią!");
            else if (Funkcje.isthere(loginrBox.Text))
                MessageBox.Show("Ta nazwa użytkownika jest już zajęta");
            else if (Funkcje.register(nameBox.Text, lnameBox.Text, loginrBox.Text, passrBox.Text))
            {
                MessageBox.Show("Zarejestrowano!");
                LogForm.logins = loginrBox.Text;
                new UserForm().Show();
                this.Hide();
            }
              
            else
                MessageBox.Show("cos poszło nie tak :/");
           
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            new LogForm().Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
