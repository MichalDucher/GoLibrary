﻿
namespace GoLibrary
{
    partial class AddBookFrm
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddBookFrm));
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.addanameBox = new System.Windows.Forms.TextBox();
            this.addalnameBox = new System.Windows.Forms.TextBox();
            this.addtitleBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.addsectBox = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.quanBox = new System.Windows.Forms.TextBox();
            this.AddBookButton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(215, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 18);
            this.label3.TabIndex = 11;
            this.label3.Text = "Nazwisko Autora";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(215, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 18);
            this.label2.TabIndex = 10;
            this.label2.Text = "Imię Autora";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(215, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 18);
            this.label1.TabIndex = 9;
            this.label1.Text = "Tytuł";
            // 
            // addanameBox
            // 
            this.addanameBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.addanameBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.addanameBox.Font = new System.Drawing.Font("Myanmar Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addanameBox.Location = new System.Drawing.Point(23, 68);
            this.addanameBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.addanameBox.Name = "addanameBox";
            this.addanameBox.Size = new System.Drawing.Size(175, 34);
            this.addanameBox.TabIndex = 8;
            // 
            // addalnameBox
            // 
            this.addalnameBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.addalnameBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.addalnameBox.Font = new System.Drawing.Font("Myanmar Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addalnameBox.Location = new System.Drawing.Point(23, 114);
            this.addalnameBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.addalnameBox.Name = "addalnameBox";
            this.addalnameBox.Size = new System.Drawing.Size(175, 34);
            this.addalnameBox.TabIndex = 7;
            // 
            // addtitleBox
            // 
            this.addtitleBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.addtitleBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.addtitleBox.Font = new System.Drawing.Font("Myanmar Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addtitleBox.Location = new System.Drawing.Point(23, 20);
            this.addtitleBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.addtitleBox.Name = "addtitleBox";
            this.addtitleBox.Size = new System.Drawing.Size(175, 34);
            this.addtitleBox.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(215, 213);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 18);
            this.label4.TabIndex = 12;
            this.label4.Text = "Dzial";
            // 
            // addsectBox
            // 
            this.addsectBox.FormattingEnabled = true;
            this.addsectBox.Items.AddRange(new object[] {
            "Matematyka",
            "Fizyka ",
            "Mechanika",
            "Elektronika",
            "Języki obce",
            "Astronomia",
            "Informatyka",
            "Technika cyfrowa",
            "Nawigacja",
            "Metrologia",
            "Elektrotechnika"});
            this.addsectBox.Location = new System.Drawing.Point(23, 209);
            this.addsectBox.Margin = new System.Windows.Forms.Padding(4);
            this.addsectBox.Name = "addsectBox";
            this.addsectBox.Size = new System.Drawing.Size(176, 24);
            this.addsectBox.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(215, 181);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 18);
            this.label5.TabIndex = 15;
            this.label5.Text = "Ilosc";
            // 
            // quanBox
            // 
            this.quanBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.quanBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.quanBox.Font = new System.Drawing.Font("Myanmar Text", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quanBox.Location = new System.Drawing.Point(23, 161);
            this.quanBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.quanBox.Name = "quanBox";
            this.quanBox.Size = new System.Drawing.Size(175, 34);
            this.quanBox.TabIndex = 14;
            // 
            // AddBookButton
            // 
            this.AddBookButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.AddBookButton.FlatAppearance.BorderSize = 0;
            this.AddBookButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddBookButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.AddBookButton.ForeColor = System.Drawing.Color.White;
            this.AddBookButton.Location = new System.Drawing.Point(23, 256);
            this.AddBookButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AddBookButton.Name = "AddBookButton";
            this.AddBookButton.Size = new System.Drawing.Size(177, 34);
            this.AddBookButton.TabIndex = 16;
            this.AddBookButton.Text = "Dodaj ksiazke";
            this.AddBookButton.UseVisualStyleBackColor = false;
            this.AddBookButton.Click += new System.EventHandler(this.AddBookButton_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(784, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(21, 20);
            this.button1.TabIndex = 19;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // AddBookFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.AddBookButton);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.quanBox);
            this.Controls.Add(this.addsectBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.addanameBox);
            this.Controls.Add(this.addalnameBox);
            this.Controls.Add(this.addtitleBox);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "AddBookFrm";
            this.Size = new System.Drawing.Size(808, 600);
            this.Load += new System.EventHandler(this.AddBookFrm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox addanameBox;
        private System.Windows.Forms.TextBox addalnameBox;
        private System.Windows.Forms.TextBox addtitleBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox addsectBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox quanBox;
        private System.Windows.Forms.Button AddBookButton;
        private System.Windows.Forms.Button button1;
    }
}
