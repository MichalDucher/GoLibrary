﻿
namespace GoLibrary
{
    partial class zwrotyfrm
    {
        /// <summary> 
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod wygenerowany przez Projektanta składników

        /// <summary> 
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować 
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(zwrotyfrm));
            this.ledGrid = new System.Windows.Forms.DataGridView();
            this.zwrotButton = new System.Windows.Forms.Button();
            this.searchBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.searchButton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ledGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // ledGrid
            // 
            this.ledGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ledGrid.Location = new System.Drawing.Point(3, 237);
            this.ledGrid.Name = "ledGrid";
            this.ledGrid.RowHeadersWidth = 51;
            this.ledGrid.RowTemplate.Height = 24;
            this.ledGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ledGrid.Size = new System.Drawing.Size(802, 360);
            this.ledGrid.TabIndex = 1;
            this.ledGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ledGrid_CellContentClick);
            // 
            // zwrotButton
            // 
            this.zwrotButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.zwrotButton.FlatAppearance.BorderSize = 0;
            this.zwrotButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.zwrotButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.zwrotButton.ForeColor = System.Drawing.Color.White;
            this.zwrotButton.Location = new System.Drawing.Point(667, 200);
            this.zwrotButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.zwrotButton.Name = "zwrotButton";
            this.zwrotButton.Size = new System.Drawing.Size(137, 31);
            this.zwrotButton.TabIndex = 2;
            this.zwrotButton.Text = "Zwróć ksiazke";
            this.zwrotButton.UseVisualStyleBackColor = false;
            this.zwrotButton.Click += new System.EventHandler(this.zwrotButton_Click);
            // 
            // searchBox
            // 
            this.searchBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(231)))), ((int)(((byte)(233)))));
            this.searchBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.searchBox.Font = new System.Drawing.Font("MS Reference Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.searchBox.Location = new System.Drawing.Point(3, 200);
            this.searchBox.Name = "searchBox";
            this.searchBox.Size = new System.Drawing.Size(216, 31);
            this.searchBox.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Myanmar Text", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label5.Location = new System.Drawing.Point(-2, 170);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 27);
            this.label5.TabIndex = 12;
            this.label5.Text = "Login";
            // 
            // searchButton
            // 
            this.searchButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(86)))), ((int)(((byte)(174)))));
            this.searchButton.FlatAppearance.BorderSize = 0;
            this.searchButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.searchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F);
            this.searchButton.ForeColor = System.Drawing.Color.White;
            this.searchButton.Location = new System.Drawing.Point(225, 200);
            this.searchButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(92, 31);
            this.searchButton.TabIndex = 14;
            this.searchButton.Text = "Szukaj";
            this.searchButton.UseVisualStyleBackColor = false;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(784, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(21, 20);
            this.button1.TabIndex = 19;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // zwrotyfrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.searchBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.zwrotButton);
            this.Controls.Add(this.ledGrid);
            this.Name = "zwrotyfrm";
            this.Size = new System.Drawing.Size(808, 600);
            this.Load += new System.EventHandler(this.zwrotyfrm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ledGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView ledGrid;
        private System.Windows.Forms.Button zwrotButton;
        private System.Windows.Forms.TextBox searchBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.Button button1;
    }
}
