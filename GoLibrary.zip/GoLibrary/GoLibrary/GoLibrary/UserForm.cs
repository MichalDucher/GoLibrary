﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GoLibrary
{
    public partial class UserForm : Form
    {
        public UserForm()
        {
            InitializeComponent();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            new LogForm().Show();
            this.Hide();
        }
        
        private void dashboard_Click(object sender, EventArgs e)
        {
            student1.Visible = true;
            findBookfrm1.Visible = false;
            mine1.Visible = false;
            
        }

        private void find_Click(object sender, EventArgs e)
        {
            student1.Visible = false;
            findBookfrm1.Visible = true;
            mine1.Visible = false;
        }

        private void wyp_Click(object sender, EventArgs e)
        {
            mine1.Visible = true;
            findBookfrm1.Visible = false;
            student1.Visible = false;
        }
    }
}
